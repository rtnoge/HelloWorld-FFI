//
//  helloWorld.h
//  helloWorld
//
//  Created by Enoge on 28/09/20.
//

#import <Foundation/Foundation.h>

@interface SampleClass : NSObject
+(NSString *)sampleMethod;
@end
