//
//  helloWorld.m
//  helloWorld
//
//  Created by Enoge on 28/09/20.
//

#import <Foundation/Foundation.h>
#import "helloWorld.h"

@implementation SampleClass
+(NSString *) sampleMethod {
    NSString *greet = @"Hello World, FFI iOS";
    return greet;
}
@end
